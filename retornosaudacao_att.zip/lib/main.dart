import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Saudação',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _nome = '';
  int _idade = 0;
  double _salario = 0.0;

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _idadeController = TextEditingController();
  TextEditingController _salarioController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Saudação'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _nomeController,
              onChanged: (value) {
                setState(() {
                  _nome = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Digite seu nome',
              ),
            ),
            TextField(
              controller: _idadeController,
              onChanged: (value) {
                setState(() {
                  _idade = int.tryParse(value) ?? 0;
                });
              },
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'Digite sua idade',
              ),
            ),
            TextField(
              controller: _salarioController,
              onChanged: (value) {
                setState(() {
                  _salario = double.tryParse(value) ?? 0.0;
                });
              },
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                hintText: 'Digite seu salário',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                _mostrarMensagem(context,
                    'Olá, $_nome! Você tem $_idade anos e seu salário é R\$ $_salario.');
              },
              child: Text('Mostrar Saudação'),
            ),
            SizedBox(height: 10.0),
            ElevatedButton(
              onPressed: () {
                _nomeController.clear();
                _idadeController.clear();
                _salarioController.clear();
                setState(() {
                  _nome = '';
                  _idade = 0;
                  _salario = 0.0;
                });
              },
              child: Text('Limpar'),
            ),
          ],
        ),
      ),
    );
  }

  void _mostrarMensagem(BuildContext context, String mensagem) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Mensagem'),
          content: Text(mensagem),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
