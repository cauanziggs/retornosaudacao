package com.example.retornosaudacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
